#ifndef COINDROP_H
#define COINDROP_H

#include <Arduino.h>
extern int sensorValues[12];
void setupsen() ;
void looping();
#endif