#include "RobotControl.h"
#include "MotorControl.h"

// Example calibration constants for the Sharp IR sensor
static const float a = 27.86;
static const float b = 0.42;

void startRobot() {
    moveForward(200, 200);
    Serial.println("Action: Robot Moving Forward");
}

int getSharpIRDistance() {
    return analogRead(SHARP_IR_PIN); // Read the sensor value directly
}

void waitForGateToClose() {
    Serial.println("Waiting for gate to close...");
    while (true) {
        int sensorValue = getSharpIRDistance(); // Read sensor value
        if (sensorValue >= STOP_DISTANCE) {    // Gate detected as closed
            break;
        }
        delay(50); // Small delay to avoid excessive polling
    }
    Serial.println("Gate detected as closed.");
}

void waitForGateToDisappear() {
    Serial.println("Waiting for gate to open...");
    while (true) {
        int sensorValue = getSharpIRDistance(); // Read sensor value
        if (sensorValue < STOP_DISTANCE) {     // Gate detected as open
            break;
        }
        delay(50); // Small delay to avoid excessive polling
    }
    Serial.println("Gate detected as open.");
}

void checkBarrier() {
        // Wait for the gate to close
        waitForGateToClose();

        // Wait for the gate to disappear
        waitForGateToDisappear();

        // Start moving the robot
        startRobot();
}