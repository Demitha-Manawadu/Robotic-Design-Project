#ifndef BARCODE_H
#define BARCODE_H
#include <Arduino.h>
#include "OLED_Display.h"
#include "Barcode.h"

void detect();
#endif
